% function Test_group_lasso

% min 0.5 * ||A * x - b||_2^2 + mu * ||x||_{1,2}

% generate data
seed = 97006855;
ss = RandStream('mt19937ar','Seed',seed);
RandStream.setGlobalStream(ss);
n = 512;
m = 256;
A = randn(m,n);
k = round(n*0.1); l = 2;
A = randn(m,n);
p = randperm(n); p = p(1:k);
u = zeros(n,l);  u(p,:) = randn(k,l);  
b = A*u;
mu = 1e-2;

x0 = randn(n, l);

errfun = @(x1, x2) norm(x1 - x2, 'fro') / (1 + norm(x1,'fro'));
errfun_exact = @(x) norm(x - u, 'fro') / (1 + norm(u,'fro'));
sparisity = @(x) sum(abs(x(:)) > 1E-6 * max(abs(x(:)))) /(n*l);

% cvx calling mosek
opts1 = []; % modify options
tic;
[x1, iter1, out1] = gl_cvx_mosek(x0, A, b, mu, opts1);
t1 = toc;

% cvx calling gurobi
opts2 = []; % modify options
tic;
[x2, iter2, out2] = gl_cvx_gurobi(x0, A, b, mu, opts2);
t2 = toc;

% call mosek directly
opts3 = []; % modify options
tic;
[x3, iter3, out3] = gl_mosek(x0, A, b, mu, opts3);
t3 = toc;

% call gurobi directly
opts4 = []; % modify options
tic;
[x4, iter4, out4] = gl_gurobi(x0, A, b, mu, opts4);
t4 = toc;

% other approaches
% Subgradient Method
opts5 = []; % modify options
tic;
[x5, iter5, out5] = gl_SGD_primal(x0, A, b, mu, opts5);
t5 = toc;

% Gradient Method for the Smoothed Primal Problem
opts6 = []; % modify options
tic;
[x6, iter6, out6] = gl_GD_primal(x0, A, b, mu, opts6);
t6 = toc;



%% print comparison results with cvx-call-mosek
fprintf('     CVX-Mosek: cpu: %5.2f, iter: %5d, optval: %6.5E, sparisity: %4.3f, err-to-exact: %3.2E, err-to-cvx-mosek: %3.2E, err-to-cvx-gurobi: %3.2E.\n', t1, iter1, out1.fval, sparisity(x1), errfun_exact(x1), errfun(x1, x1), errfun(x2, x1));
fprintf('    CVX-Gurobi: cpu: %5.2f, iter: %5d, optval: %6.5E, sparisity: %4.3f, err-to-exact: %3.2E, err-to-cvx-mosek: %3.2E, err-to-cvx-gurobi: %3.2E.\n', t2, iter2, out2.fval, sparisity(x2), errfun_exact(x2), errfun(x1, x2), errfun(x2, x2));
fprintf('         Mosek: cpu: %5.2f, iter: %5d, optval: %6.5E, sparisity: %4.3f, err-to-exact: %3.2E, err-to-cvx-mosek: %3.2E, err-to-cvx-gurobi: %3.2E.\n', t3, iter3, out3.fval, sparisity(x3), errfun_exact(x3), errfun(x1, x3), errfun(x2, x3));
fprintf('        Gurobi: cpu: %5.2f, iter: %5d, optval: %6.5E, sparisity: %4.3f, err-to-exact: %3.2E, err-to-cvx-mosek: %3.2E, err-to-cvx-gurobi: %3.2E.\n', t4, iter4, out4.fval, sparisity(x4), errfun_exact(x4), errfun(x1, x4), errfun(x2, x4));
fprintf('    SGD Primal: cpu: %5.2f, iter: %5d, optval: %6.5E, sparisity: %4.3f, err-to-exact: %3.2E, err-to-cvx-mosek: %3.2E, err-to-cvx-gurobi: %3.2E.\n', t5, iter5, out5.fval, sparisity(x5), errfun_exact(x5), errfun(x1, x5), errfun(x2, x5));
fprintf('     GD Primal: cpu: %5.2f, iter: %5d, optval: %6.5E, sparisity: %4.3f, err-to-exact: %3.2E, err-to-cvx-mosek: %3.2E, err-to-cvx-gurobi: %3.2E.\n', t6, iter6, out6.fval, sparisity(x6), errfun_exact(x6), errfun(x1, x6), errfun(x2, x6));


% fig = figure(1);
% subplot(5,1,1); 
% % plot(1:n, u(:,1), '*');
% plot(1:n, u(:,1), '*', 1:n, u(:,2), 'o'); 
% xlim([1 n])
% title('(0) exact solution $u$', 'Interpreter','latex');

% subplot(5,1,2); 
% % plot(1:n, u(:,1), '*');
% plot(1:n, x1(:,1), '*', 1:n, x1(:,2), 'o'); 
% xlim([1 n])
% title('(1) CVX-Mosek solution $x1$', 'Interpreter','latex');


% subplot(5,1,3); 
% % plot(1:n, u(:,1), '*');
% plot(1:n, x2(:,1), '*', 1:n, x2(:,2), 'o'); 
% xlim([1 n])
% title('(2) CVX-Gurobi solution $x2$', 'Interpreter','latex');


% subplot(5,1,4); 
% % plot(1:n, u(:,1), '*');
% plot(1:n, x3(:,1), '*', 1:n, x3(:,2), 'o'); 
% xlim([1 n])
% title('(3) Mosek solution $x3$', 'Interpreter','latex');

% subplot(5,1,5); 
% % plot(1:n, u(:,1), '*');
% plot(1:n, x4(:,1), '*', 1:n, x4(:,2), 'o'); 
% xlim([1 n])
% title('(4) Gurobi solution $x4$', 'Interpreter','latex');


fig = figure(1);
subplot(2,1,1); 
% plot(1:n, u(:,1), '*');
plot(1:n, x5(:,1), '*', 1:n, x5(:,2), 'o'); 
xlim([1 n])
title('(5) SGD solution $x3$', 'Interpreter','latex');

subplot(2,1,2); 
% plot(1:n, u(:,1), '*');
plot(1:n, x6(:,1), '*', 1:n, x6(:,2), 'o'); 
xlim([1 n])
title('(6) GD solution $x4$', 'Interpreter','latex');


%plot_results(u, 'Exact', '../figures/gl_exact.png', u, x1, x2)
%plot_results(x1, 'CVX-Mosek', '../figures/gl_cvx_mosek.png', u, x1, x2)
%plot_results(x2, 'CVX-Gurobi', '../figures/gl_cvx_gurobi.png', u, x1, x2)

%plot_results(x3, 'Mosek', '../figures/gl_mosek.png', u, x1, x2)
%plot_results(x4, 'Gurobi', '../figures/gl_gurobi.png', u, x1, x2)


